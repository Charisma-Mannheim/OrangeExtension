Orange3 CHARISMA
=================


Installation
------------

To install the add-on, run

    pip install -e .

Documentation / widget help can be built by running

    make html 

from the doc directory.

Usage
-----

After the installation, the widget from this add-on is registered with Orange. To run Orange from the terminal,
use

    Orange-canvas

The new widget appears in the toolbox bar under the section Extension.


